from io import BytesIO

from PIL import Image
from flask import Flask, url_for
from flask import request

app = Flask(__name__)


@app.route('/carousel')
def promotion():
    return f"""<!doctype html>
                <html lang="ru">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport"
                          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
                    <meta http-equiv="X-UA-Compatible" content="ie=edge">
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
                          integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
                    <link href="./static/css/style.css" rel="stylesheet">
                    <title>Варианты выбора</title>
                </head>
                <body>
                <div class="container">
                    <h1>Пейзажи Марса</h1>
                
                    <div id="carouselExample" class="carousel slide">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="{url_for('static', filename='img/mars1.jpg')}" class="d-block w-100" alt="...">
                            </div>
                
                            <div class="carousel-item">
                                <img src="{url_for('static', filename='img/mars2.jpg')}" class="d-block w-100" alt="...">
                            </div>
                
                            <div class="carousel-item">
                                <img src="{url_for('static', filename='img/mars3.jpg')}" class="d-block w-100" alt="...">
                            </div>
                
                            <div class="carousel-item">
                                <img src="{url_for('static', filename='img/mars4.jpg')}" class="d-block w-100" alt="...">
                            </div>
                
                        </div>
                
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                
                    </div>
                
                </div>
                
                
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
                        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
                        crossorigin="anonymous"></script>
                
                </body>
                </html>"""


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080)

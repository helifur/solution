import os

from flask import Flask
from flask import render_template, redirect, request

from flask_wtf import FlaskForm
from wtforms import SubmitField, FileField
from wtforms.validators import DataRequired


class LoadForm(FlaskForm):
    image = FileField('Добавить картинку', validators=[DataRequired()])
    submit = SubmitField('Отправить')


app = Flask(__name__, template_folder="templates")
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['UPLOAD_FOLDER'] = 'static/img/'


@app.route('/carousel')
def promotion():
    files = []

    for (_, __, filenames) in os.walk('static/img'):
        files.extend(filenames)
        break

    files = [f'/static/img/{elem}' for elem in files]

    print(files)

    return render_template("index.html", files=files)


@app.route('/gallery', methods=['GET', 'POST'])
def gallery():
    if request.method == 'POST':
        file = request.files['image']
        filename = file.filename

        if file.filename == '':
            return redirect(request.url)

        if filename.split('.')[-1].lower() not in ['png', 'jpg', 'jpeg']:
            return redirect(request.url)

        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        return redirect('/success')

    else:
        form = LoadForm()

        if form.validate_on_submit():
            return redirect('/success')

        return render_template("load.html", form=form)


@app.route('/success')
def success():
    return "Файл успешно загружен!"


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)

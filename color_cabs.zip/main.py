import random
from flask import Flask
from flask import render_template, url_for

app = Flask(__name__, template_folder='templates')
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/table/<sex>/<age>')
def index(sex, age):
    if sex == "female" and age == "25":
        return render_template('index.html', path_img=url_for('static', filename='img/adult.jpg'), color="#ff4500")

    if sex == "female" and age == "15":
        return render_template('index.html', path_img=url_for('static', filename='img/child.jpg'), color="#ffa07a")

    if sex == "male" and age == "15":
        return render_template('index.html', path_img=url_for('static', filename='img/child.jpg'), color="#b0c4de")

    if sex == "male" and age == "25":
        return render_template('index.html', path_img=url_for('static', filename='img/adult.jpg'), color="#007ff0")

    return "Ошибка!"


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=8080)

import random
from flask import Flask
from flask import render_template, url_for

app = Flask(__name__, template_folder='templates')
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/table/<sex>/<age>')
def index(sex, age):
    # случайный цвет
    def color():
        color = "#{:06x}".format(random.randint(0, 0xFFFFFF))
        return color

    if int(age) < 21:
        return render_template('index.html', path_img=url_for('static', filename='img/child.jpg'), color=color())

    return render_template('index.html', path_img=url_for('static', filename='img/adult.jpg'), color=color())


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=8080)

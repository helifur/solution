from flask_restful import reqparse


parser_jobs = reqparse.RequestParser()
parser_jobs.add_argument('job', required=True)
parser_jobs.add_argument('team_leader', required=True, type=int)
parser_jobs.add_argument('collaborators', required=True)
parser_jobs.add_argument('work_size', required=True, type=int)
parser_jobs.add_argument('is_finished', required=True, type=bool)

parser_users = reqparse.RequestParser()
parser_users.add_argument('surname', required=True)
parser_users.add_argument('name', required=True)
parser_users.add_argument('speciality', required=True)
parser_users.add_argument('position', required=True)
parser_users.add_argument('age', required=True, type=int)
parser_users.add_argument('address', required=True)
parser_users.add_argument('email', required=True)
parser_users.add_argument('hashed_password', required=True)

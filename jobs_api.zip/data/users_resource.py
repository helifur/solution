from flask_restful import abort, Resource
from flask import jsonify

from data import db_session
from data.users import User
from data.parser import parser_users


def abort_if_user_not_found(user_id):
    db_session.global_init('db/mars_explorer.sqlite')
    session = db_session.create_session()
    user = session.query(User).get(user_id)
    if not user:
        abort(404, message=f"User {user_id} not found")


class UserResource(Resource):
    def get(self, user_id):
        abort_if_user_not_found(user_id)
        db_session.global_init('db/mars_explorer.sqlite')
        session = db_session.create_session()
        user = session.query(User).get(user_id)
        return jsonify({'user': user.to_dict(only=('surname', 'name', 'age', 'position', 'speciality', 'address', 'email', 'hashed_password'))})

    def delete(self, user_id):
        abort_if_user_not_found(user_id)
        db_session.global_init('db/mars_explorer.sqlite')
        session = db_session.create_session()
        user = session.query(User).get(user_id)
        session.delete(user)
        session.commit()
        return jsonify({'success': 'OK'})


class UserListResource(Resource):
    def get(self):
        db_session.global_init('db/mars_explorer.sqlite')
        session = db_session.create_session()
        user = session.query(User).all()
        return jsonify({'user': [item.to_dict(only=('surname', 'name', 'age', 'position', 'speciality', 'address', 'email', 'hashed_password')) for item in user]})

    def post(self):
        args = parser_users.parse_args()
        db_session.global_init('db/mars_explorer.sqlite')
        session = db_session.create_session()
        user = User(
            surname=args['surname'],
            name=args['name'],
            age=args['age'],
            position=args['position'],
            speciality=args['speciality'],
            address=args['address'],
            email=args['email'],
            hashed_password=args['hashed_password']
        )
        session.add(user)
        session.commit()
        return jsonify({'success': 'OK'})

from flask import Flask
from flask_restful import Api

from data.users_resource import UserListResource, UserResource
from data.jobs_resource import JobsListResource, JobsResource
from data import db_session


db_session.global_init('db/mars_explorer.sqlite')


app = Flask(__name__, template_folder="/static/templates")
api = Api(app)


if __name__ == '__main__':
    api.add_resource(UserListResource, '/api/v2/users')
    api.add_resource(UserResource, '/api/v2/users/<int:user_id>')

    api.add_resource(JobsListResource, '/api/v2/jobs')
    api.add_resource(JobsResource, '/api/v2/jobs/<int:jobs_id>')

    app.run(port=8080, host='127.0.0.1', debug=True)

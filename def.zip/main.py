from flask import Flask
from flask import render_template, redirect
from loginform import LoginForm

app = Flask(__name__, template_folder='templates')
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/')
@app.route('/auto_answer')
def index():
    form = LoginForm()

    return render_template('index.html', form=form)


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=8080)

from requests import get, post, delete

print(get('http://127.0.0.1:8080/api/v2/users').json())
print(get('http://127.0.0.1:8080/api/v2/users/2').json())
print(get('http://127.0.0.1:8080/api/v2/users/98345043').json())
print(post('http://127.0.0.1:8080/api/v2/users', json={'surname': 'Dwegwe',
                                                       'name': 'Fwefe',
                                                       'age': 34,
                                                       'speciality': 'dweqgt',
                                                       'position': 'dwegfetw',
                                                       'address': 'edwqtg',
                                                       'email': 'dwqt3qwgved',
                                                       'hashed_password': 'fgerlgh'}).json())

print(delete('http://127.0.0.1:8080/api/v2/users/8').json())

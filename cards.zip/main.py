import json

from flask import Flask
from flask import render_template


app = Flask(__name__, template_folder="templates")


@app.route('/member')
def promotion():
    with open('templates/data.json') as cat_file:
        data = json.load(cat_file)

    return render_template("index.html", data=data)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)

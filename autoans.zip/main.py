from flask import Flask
from flask import render_template

app = Flask(__name__, template_folder='templates')


@app.route('/answer')
@app.route('/auto_answer')
def index():
    data = {}
    data['title'] = 'Анкета'
    data['surname'] = 'Watny'
    data['name'] = 'Mark'
    data['education'] = 'выше среднего'
    data['profession'] = 'штурман марсохода'
    data['sex'] = 'male'
    data['motivation'] = 'Всегда мечтал застрять на Марсе!'
    data['ready'] = 'True'

    return render_template('index.html', **data)


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=8080)
